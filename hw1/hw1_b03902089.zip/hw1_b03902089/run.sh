make
make trn
make tst
make acc
